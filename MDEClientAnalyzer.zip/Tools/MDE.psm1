﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2021 v5.8.194
	 Created on:   	10/19/2021 3:50 PM
	 Created by:   	ksarens
	 Updated 10/26/2102
	 	fixing error in help information
	 	adding support for offline scenarios
	 Organization: 	
	 Filename:     	MDEHelper.psm1
	===========================================================================
	.DESCRIPTION
		Helper functions for MDE Support solutions
#>

function checkEPPVersion
{
	<#
.SYNOPSIS
	Supportability of Defender EPP components
.DESCRIPTION
    Returns if the provided version of a component (MoCAMP, Engine, Sigs) is lower than the version online and no longer supported
.PARAMETER component
    The component to verify, this can be: MoCAMP|Engine|Sigs
.PARAMETER version
    The version of the component
.PARAMETER xml
    XML document containing the online versions (only needed in offline scenarios). In offline scenarios, the XML document needs to be provided, NOT the path to the xml file
.EXAMPLE
	checkEPPVersion -component MoCAMP -version 4.18.2009.6
        The result of the above example is True as this version is older than N-2 and no longer supported
.NOTES
	If there is no internet connectivity, the method will return $null, in this case provide the XML parameter (see above)
.LINK
#>
	[CmdletBinding()]
	Param (
		[Parameter(Mandatory = $true, Position = 0)]
		[ValidateSet('MoCAMP', 'Engine','Sigs')]
		[string]$component,
		[Parameter(Mandatory = $true, Position = 1)]
		[string]$version,
		[Parameter(Mandatory = $false)]
		[xml]$xml
	)
	
	Begin
	{
		$catch=$false
		if ($null -eq $script:EPP_Versions)
		{
			try {
				if($null -eq $xml)
				{
					$Response = Invoke-WebRequest -URI "https://www.microsoft.com/security/encyclopedia/adlpackages.aspx?action=info" -UseBasicParsing
					[xml]$xml = $Response.Content
				}
			}
			catch {
				$catch=$true
			}
			
			
			$script:EPP_Versions = New-Object System.Management.Automation.PSObject
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "MoCAMP" -NotePropertyValue $xml.ChildNodes[1].platform
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Engine" -NotePropertyValue $xml.ChildNodes[1].engine
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Sigs" -NotePropertyValue $xml.ChildNodes[1].signatures.'#text'
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Date" -NotePropertyValue $xml.ChildNodes[1].signatures.date
			Add-Member -InputObject $script:EPP_Versions -NotePropertyName "Updated" -NotePropertyValue (Get-Date -Format "MM/dd/yyyy HH:mm")
		}
		if ($version -like "*-*")
		{
			$version = $version.split('-')[0]
		}
	}
	Process
	{
		if($catch)
		{return $null}
		Try
		{
			switch ($component)
			{
				"MoCAMP" {
					
					if ([System.version]$script:EPP_Versions.MoCAMP -gt [System.version]$version)
					{
						$online = @()
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[0]
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[1]
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[2]
						$online += [int]$script:EPP_Versions.MoCAMP.split('.')[3]
						
						$current = @()
						$current += [int]$version.split('.')[0]
						$current += [int]$version.split('.')[1]
						$current += [int]$version.split('.')[2]
						$current += [int]$version.split('.')[3]
						if (($online[2] - $current[2]) -ge 3 -or (($online[2] - $current[2]) -gt 90 -and ($online[2] - $current[2]) -lt 92))
						{
							return $true
						}
						return $false
					}
				}
				"Sigs" {
					if ([System.version]$script:EPP_Versions.Sigs -gt [System.version]$version)
					{
						return $true
					}
				}
				"Engine" {
					if ([System.version]$script:EPP_Versions.Engine -gt [System.version]$version)
					{
						return $true
					}
				}
			}
			return $false
		}
		Catch
		{
			#Write-Log -Message "ERROR $($MyInvocation.MyCommand) [$($var)] - [$_]" -Severity 3
		}
		
	}
	End
	{
		[GC]::Collect()
	}
}
Export-ModuleMember checkEPPVersion
# SIG # Begin signature block
# MIIoTgYJKoZIhvcNAQcCoIIoPzCCKDsCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA9YhaHHSHxLWs4
# 82HsnJ7/cUuUmBqC+dakbmWaA9IjGKCCDZcwggYVMIID/aADAgECAhMzAAADcaWg
# nFyRHuruAAAAAANxMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjMwNTExMTg0MTEzWhcNMjQwNTA4MTg0MTEzWjCBlDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjE+MDwGA1UEAxM1TWlj
# cm9zb2Z0IFdpbmRvd3MgRGVmZW5kZXIgQWR2YW5jZWQgVGhyZWF0IFByb3RlY3Rp
# b24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDQl+fOHFGkNfDHrcv3
# g8shIsUp58WmSbtNm4uu7Sw75Wgsgo5p2yYGGqiRWbu0eIKhAJ1bRp9Qa7vAjMEw
# d0wf9wlLjDNAITzDsokwoCl0rOgWxzYuGSusZq4e/liClIpY5fuxrpsEnsssR1o6
# jITkdJQ6ZkWsTFETxLLOEGxe9BkTkXZaBOHlhTt5QIq6UB6j8zNN/Vo4rFmq751X
# lQLA1jOnNi5NOS3/11TW16ZCo9XKG22zdNsJCUckT/QH2eeQNgpuyfIvP06o+RpP
# Uo7P4xdc4c74S3HKfRiNuqbs3+xvb22GtXIz3cKFDhILpNKN/SC8qLjizq0PxwL1
# lr1ZAgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBggrBgEFBQcDAwYKKwYBBAGCN0wv
# ATAdBgNVHQ4EFgQUcR5wDY+Mh5A/I7scm54A8ODeSVcwRQYDVR0RBD4wPKQ6MDgx
# HjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEWMBQGA1UEBRMNNDUxODk0
# KzUwMTAwNTAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzcitW2oynUClTBUBgNVHR8E
# TTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NybC9N
# aWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEGCCsGAQUFBwEBBFUwUzBR
# BggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraW9wcy9jZXJ0
# cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0MAwGA1UdEwEB/wQCMAAw
# DQYJKoZIhvcNAQELBQADggIBAKYhzPfo4pWE2MYg2W1VnHJ7NZ/nwEpGYEz7Qhqc
# bPj2sJFFhnUzYHOAyXz4vP0+ERhFw9lrqLvoyj8s6xQU11QPQVItopahH65USGWh
# UcyrXFBVSx7MG3Dwi+NT6rxq9MjY3KLB1hZPF7hgtOjWgtjXgeJOsy3IjPiRkDwX
# 5b5Pg6o8Xpyt84mpvAPsDKO7yJGJq8V528deIYh+0DcELvUZTtl4Kz8ElT4BxF6i
# XxXkuqpCWO/rwEa6HrLNV2udND/AImVio09bbZXOWBcb9uTTNezYX5fZvinIX7hl
# UHHIDaVUqqwTFtac8q7BLE02T0P7NAeBtayujIQFzGNuwLN302UmUWAyc4LynqZa
# h2OmZWcMODUCuHIMP3pk54XjWt0YYEWPFAbA7T7j8wjby/vPXdG93LybID/yjGDb
# U1t5xMoEpN5rvSUM1U42iJ1tF268/nE2/8nKqUpdJXH/MaXxYU3FnbshmIe1xfxF
# NjeMYN4jg+5gjz5SBzHAhT1X9QWXNOhAXxib3wcchlsxFYtSNihHLEJ2GuckRuPi
# 47VWi/3hTTnl88S8r3jsbWLatGbQxcbrsF4sglAvFD9SQSXLGUsE5wz/1p/Gb1Fh
# qfNBc6E4AWVj9+A1KezSnMBAw8gJk3fiRkdxfSfpLOkHvgA7qsOmQ7qwjs05kWZf
# 055CMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG9w0BAQsFADCBiDEL
# MAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1v
# bmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWlj
# cm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEwHhcNMTEwNzA4
# MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAq/D6chAcLq3Y
# bqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS2AvwOMKZBrDIOdUB
# FDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJr9eWWcpgGgXpZnbo
# MlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSsbmQ1eKagYw8t00CT
# +OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6t0le2O3tQ5GD2Xuy
# e4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKvkjh+0p2ALPVOVpEh
# NSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVfGCi2zCcoOCWYOUo2
# z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DRelsv1SPjcF0PUUZ3
# s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J64HLnJN+/RpnF78Ic
# V9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyimp31ngOaKYnhfsi+E
# 11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu+HggWCwTXWCVmj5P
# M4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHpMBAGCSsGAQQBgjcV
# AQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUClTAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAf
# BgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNVHR8EUzBRME+gTaBL
# hklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNS
# b29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUFBwEBBFIwUDBOBggr
# BgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNS
# b29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAEgZcwgZQwgZEGCSsG
# AQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwA
# ZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0AZQBuAHQALiAdMA0G
# CSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR4WOSmUKWfdJ5DJDB
# ZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9i0ZQVdgMknzSGksc
# 8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MTfaaQdION9MsmAkYq
# wooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/zRive/DvQvTXvbiWu
# 5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkKxgrCxq2u5bLZ2xWI
# UUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASooPoI/E01mC8CzTfXh
# j38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HNpZfQ7l1jQeNbB5yH
# PgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbYANahRr1Z85elCUtI
# EJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74v2u3S5fi63V4Guzq
# N5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E90Z1WTk+/gFcioXgR
# MiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmfwb1tbWrJUnMTDXpQ
# zTGCGg0wghoJAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEC
# EzMAAANxpaCcXJEe6u4AAAAAA3EwDQYJYIZIAWUDBAIBBQCgga4wGQYJKoZIhvcN
# AQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUw
# LwYJKoZIhvcNAQkEMSIEIAu+b3Dxo76vP1XyJFnB7JUB+pPSFO8Gxi1g1xC2p8kh
# MEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8AcwBvAGYAdKEagBhodHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEBBQAEggEAGxPWRfoEW5HE
# 8JuWv9WNTxFJGc9Vg0jFLIvU1gslnzDcQ93SAHfwnzuGFgfU+LeO3hVILMdxJTp2
# v/DG0uC/d9zGUkoPW0+CWykO8d4qKmWfgEA1AWJ246LGKTbCyubGNVsJVAUOxRYG
# ekKTnmcD5KgAY/zJsTnHl5VEjAtFjbndBgHZ/OIXQkD8Zv7rkMAtR7uyWaqP40a2
# nq7hg+SJpqpAfxMPkwHr1Mjb3Ed+YUhZE4Ny4NdaTc4dNbD6WJGNUKx73DZQHzZu
# JOK0rbeHrhbul+tYbC/dr1WJIu0yi8TXgnDXKRXF5INLXSXXnVR4pm1FQ4D22bWd
# 31valmvDKKGCF5cwgheTBgorBgEEAYI3AwMBMYIXgzCCF38GCSqGSIb3DQEHAqCC
# F3AwghdsAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFSBgsqhkiG9w0BCRABBKCCAUEE
# ggE9MIIBOQIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFlAwQCAQUABCCrODsLm4m1
# LnN0UI6HJOyXekutqphjfzFBlronfdqj5QIGZSitw6efGBMyMDIzMTAyOTEwMjQz
# Ni42NzhaMASAAgH0oIHRpIHOMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MScwJQYDVQQLEx5uU2hpZWxkIFRTUyBFU046RTAwMi0wNUUwLUQ5NDcxJTAjBgNV
# BAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WgghHtMIIHIDCCBQigAwIB
# AgITMwAAAdmcXAWSsINrPgABAAAB2TANBgkqhkiG9w0BAQsFADB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMzA2MDExODMyNThaFw0yNDAyMDExODMy
# NThaMIHLMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSUwIwYD
# VQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMScwJQYDVQQLEx5uU2hp
# ZWxkIFRTUyBFU046RTAwMi0wNUUwLUQ5NDcxJTAjBgNVBAMTHE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFNlcnZpY2UwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQDV6SDN1rgY2305yLdCdUNvHCEE4Z0ucD6CKvL5lA7HM81SMkW36RU77UaBL9PS
# cviqfVzE2r2pRbRMtDBMwEx1iaizV2EZsNGGuzeR3XNYObQvJVLaCiBktAZdq75B
# NFIil+SfdpXgKzVQZiDBJDN50WCADNrrb48Z4Z7/KvyzaD4Gb+aZeCioB2Gg1m53
# d+6pUTBc3WO5xHZi/rrI/XdnhiE6/bspjpU5aufClIDx0QDq1QRw04adrKhcDWyG
# L3SaBp/hjN+4JJU7KzvsKWZVdTuXPojnaTwWcHdEGfzxiaF30zd8SY4YRUcMGPOQ
# ORH1IPwkwwlqQkc0HBkJCQziaXY/IpgMRw/XP4Uv+JBJ8RZGKZN1zRPWT9d5vHGU
# SmX3m77RKoCfkgSJifIiQi6Fc0OYKS6gZOA7nd4t+liArr9niqeC/UcNOuVrcVC4
# CbkwfJ2eHkaWh18sUt3UD8QHYLQwn95P+Hm8PZJigr1SRLcsm8pOPee7PBbndI/V
# eKJsmQdjek2aFO9VGnUtzDDBowlhXshswZMMkLJ/4jUzQmUBfm+JAH1516E+G02w
# S7NgzMwmpHWCmAaFdd7DyJIqGa6bcZrR7QALdkwIhVQDgzZAuNxqwvh4Ia4ZI5Vo
# yj4b7zWAhmurpwpMpijz+ieeWwf6ZdmysRjR/yZ6UXmGawIDAQABo4IBSTCCAUUw
# HQYDVR0OBBYEFBw6wSlTZ6gFXl05w/s3Ga1f51wnMB8GA1UdIwQYMBaAFJ+nFV0A
# XmJdg/Tl0mWnG1M1GelyMF8GA1UdHwRYMFYwVKBSoFCGTmh0dHA6Ly93d3cubWlj
# cm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY3Jvc29mdCUyMFRpbWUtU3RhbXAlMjBQ
# Q0ElMjAyMDEwKDEpLmNybDBsBggrBgEFBQcBAQRgMF4wXAYIKwYBBQUHMAKGUGh0
# dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lvcHMvY2VydHMvTWljcm9zb2Z0JTIw
# VGltZS1TdGFtcCUyMFBDQSUyMDIwMTAoMSkuY3J0MAwGA1UdEwEB/wQCMAAwFgYD
# VR0lAQH/BAwwCgYIKwYBBQUHAwgwDgYDVR0PAQH/BAQDAgeAMA0GCSqGSIb3DQEB
# CwUAA4ICAQAqNtVYLO61TMuIanC7clt0i+XRRbHwnwNo05Q3s4ppFtd4nCmB/TJP
# DJ6uvEryxs0vw5Y+jQwUiKnhl2VGGwIq0pWDIuaW4ppMV1pYQfJ6dtBGkRiTP1eK
# VvARYZMRaITe9ZhwJJnYP83pMxHCxaEsZC4ilY3/55dqd4ZXTCz/cpG5anmDartn
# WmgysygNstTwbWJJRj85gYRkjxi/nxKAiEFxl6GfkcnXVy8DRFQj1d3AiqsePoeI
# zxu1iuAJRwDrfe4NnKHqoTgWsv7eCWJnWjWWRt7RRGrpvzLQo/BxUb8i49UwRg9G
# 5bxpd5Su1b224Gv6G1HRU+qJHB1zoe41D2r/ic2BPousV9neYK5qI5PHLshAn6YT
# QllbV9pCbOUvZO0dtdwp5HH2fw6ofJNwKcPElaqkEcxvrhhRWqwNgaEVTyIV4jMc
# 8jPbx2Nh9zAztnb9NfnDFOE+/gF8cZqTa/T65TGNP3uMiP3gr8nIXQ2IRwMVUoLm
# Gu2qfmhDoews3dcvk6s1aA6mXHw+MANEIDKKjw3i2G6JtZkEemu1OXtskg/tGnfy
# waMgq5CauU9b6enTtA+UE+GKnmiQW6YUHPhBI0L2QG76TRBre5PpNVHiyc/01bjU
# EMpeaB+InAH4nDxYXx18wbJE+e/IbMv0147EFL792dELF0XwqqcU0TCCB3EwggVZ
# oAMCAQICEzMAAAAVxedrngKbSZkAAAAAABUwDQYJKoZIhvcNAQELBQAwgYgxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jv
# c29mdCBSb290IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTIxMDkzMDE4
# MjIyNVoXDTMwMDkzMDE4MzIyNVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldh
# c2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBD
# b3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIw
# MTAwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDk4aZM57RyIQt5osvX
# JHm9DtWC0/3unAcH0qlsTnXIyjVX9gF/bErg4r25PhdgM/9cT8dm95VTcVrifkpa
# /rg2Z4VGIwy1jRPPdzLAEBjoYH1qUoNEt6aORmsHFPPFdvWGUNzBRMhxXFExN6AK
# OG6N7dcP2CZTfDlhAnrEqv1yaa8dq6z2Nr41JmTamDu6GnszrYBbfowQHJ1S/rbo
# YiXcag/PXfT+jlPP1uyFVk3v3byNpOORj7I5LFGc6XBpDco2LXCOMcg1KL3jtIck
# w+DJj361VI/c+gVVmG1oO5pGve2krnopN6zL64NF50ZuyjLVwIYwXE8s4mKyzbni
# jYjklqwBSru+cakXW2dg3viSkR4dPf0gz3N9QZpGdc3EXzTdEonW/aUgfX782Z5F
# 37ZyL9t9X4C626p+Nuw2TPYrbqgSUei/BQOj0XOmTTd0lBw0gg/wEPK3Rxjtp+iZ
# fD9M269ewvPV2HM9Q07BMzlMjgK8QmguEOqEUUbi0b1qGFphAXPKZ6Je1yh2AuIz
# GHLXpyDwwvoSCtdjbwzJNmSLW6CmgyFdXzB0kZSU2LlQ+QuJYfM2BjUYhEfb3BvR
# /bLUHMVr9lxSUV0S2yW6r1AFemzFER1y7435UsSFF5PAPBXbGjfHCBUYP3irRbb1
# Hode2o+eFnJpxq57t7c+auIurQIDAQABo4IB3TCCAdkwEgYJKwYBBAGCNxUBBAUC
# AwEAATAjBgkrBgEEAYI3FQIEFgQUKqdS/mTEmr6CkTxGNSnPEP8vBO4wHQYDVR0O
# BBYEFJ+nFV0AXmJdg/Tl0mWnG1M1GelyMFwGA1UdIARVMFMwUQYMKwYBBAGCN0yD
# fQEBMEEwPwYIKwYBBQUHAgEWM2h0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2lv
# cHMvRG9jcy9SZXBvc2l0b3J5Lmh0bTATBgNVHSUEDDAKBggrBgEFBQcDCDAZBgkr
# BgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUw
# AwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBN
# MEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0
# cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoG
# CCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01p
# Y1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDANBgkqhkiG9w0BAQsFAAOCAgEAnVV9
# /Cqt4SwfZwExJFvhnnJL/Klv6lwUtj5OR2R4sQaTlz0xM7U518JxNj/aZGx80HU5
# bbsPMeTCj/ts0aGUGCLu6WZnOlNN3Zi6th542DYunKmCVgADsAW+iehp4LoJ7nvf
# am++Kctu2D9IdQHZGN5tggz1bSNU5HhTdSRXud2f8449xvNo32X2pFaq95W2KFUn
# 0CS9QKC/GbYSEhFdPSfgQJY4rPf5KYnDvBewVIVCs/wMnosZiefwC2qBwoEZQhlS
# dYo2wh3DYXMuLGt7bj8sCXgU6ZGyqVvfSaN0DLzskYDSPeZKPmY7T7uG+jIa2Zb0
# j/aRAfbOxnT99kxybxCrdTDFNLB62FD+CljdQDzHVG2dY3RILLFORy3BFARxv2T5
# JL5zbcqOCb2zAVdJVGTZc9d/HltEAY5aGZFrDZ+kKNxnGSgkujhLmm77IVRrakUR
# R6nxt67I6IleT53S0Ex2tVdUCbFpAUR+fKFhbHP+CrvsQWY9af3LwUFJfn6Tvsv4
# O+S3Fb+0zj6lMVGEvL8CwYKiexcdFYmNcP7ntdAoGokLjzbaukz5m/8K6TT4JDVn
# K+ANuOaMmdbhIurwJ0I9JZTmdHRbatGePu1+oDEzfbzL6Xu/OHBE0ZDxyKs6ijoI
# Yn/ZcGNTTY3ugm2lBRDBcQZqELQdVTNYs6FwZvKhggNQMIICOAIBATCB+aGB0aSB
# zjCByzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UE
# CxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEnMCUGA1UECxMeblNoaWVs
# ZCBUU1MgRVNOOkUwMDItMDVFMC1EOTQ3MSUwIwYDVQQDExxNaWNyb3NvZnQgVGlt
# ZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQDiHEW6Ca3n5BgZV/tQ/fCR
# 09Tf96CBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqG
# SIb3DQEBCwUAAgUA6OhDBzAiGA8yMDIzMTAyOTAyMzM0M1oYDzIwMjMxMDMwMDIz
# MzQzWjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDo6EMHAgEAMAoCAQACAg6jAgH/
# MAcCAQACAhK0MAoCBQDo6ZSHAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQB
# hFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQELBQADggEB
# AG98r0Hc9PadzpO+K9myCmYtfPJsuh65bIxYun0POTprzvxWHwahcy+mZW+Jdc7O
# mHWDcPLmv0DbT7DOWtj+bNT1ib1PXJ23aUzR6Xjvr4CVt5SyoR1jyNdu4/fJoePV
# rH57381rn9WTdXx4CCD2cvDGwc445TddjCt5kfQNDBzEcIiDkWaotQdx6OGGxN0f
# kJ+/rypvZdY7xK3uT6dvAgBZqrS5//Mtiw+tGxwuBz9Frn/MVT2ynHGyfivfQnjM
# SBtNxZNSPS82Bt5DPuoeTsgDoEWllkI7iVznCxSTmImq4M5fZycbInSdRDgcTaon
# rKWe1K6MPWXoi1TJDCKNRDYxggQNMIIECQIBATCBkzB8MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1T
# dGFtcCBQQ0EgMjAxMAITMwAAAdmcXAWSsINrPgABAAAB2TANBglghkgBZQMEAgEF
# AKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEi
# BCAKXTIZ1vNHoqQCtQuHpL5zF8/etZwXc62S3scXIDr2ajCB+gYLKoZIhvcNAQkQ
# Ai8xgeowgecwgeQwgb0EIJ+gFbItOm/UMDAnETzbJe0u0DWd2Mgpgb0ScbQgB3nz
# MIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAHZnFwF
# krCDaz4AAQAAAdkwIgQg2+qpS2nWCN93RkjwP/4Xk0/YFTmj2hOOA+iYa8q6tocw
# DQYJKoZIhvcNAQELBQAEggIAeNQCvJ+8/0HGP3QdGqXfxCuRtaE/VMoJ8ToD2oSy
# ERsW3CLPmHJyyqVBH5/ANxQHkAGN2dqeM+kG8NqMdSVDaup/i9bm9cBENau3YADT
# f2ZKJwU3laVZGVvN4NMwXYKRBXuI9dfzKLJ0xEPlHeT9AoJdJPSYQJTlTtI4A58I
# Nq6DNe4GZv5UiREoyYKfO2NLLYcLnr6MTn+OdlI5nQuHmxyJ8xFNjjScbNdcimJ/
# I6m/1nAFckb3NSbcGJ/s4LA8HTarqijzv8k2KC6GMDNsUFDHWFs7SAK4DoPav2ZU
# zWUxr1V/zZkmJqSW7LGDBWvAHVsEkNY3uSOzQiA4tAUAAcpoY8pDz1Trj9Vl8Qby
# R1/al+hQ/Wld6nRflOTENeh6zBL18WS4dAyxsFuKYIPZpPEadw/qbjiUMFf/n4EJ
# J0Ljf2CU1f7N3T5+z2exs7Q1brTGkUCsMiyQ9ZQSbiy/K8vnPr6p+2xGigRJLrPd
# Jz6HC/pxxROpIhXXUkoctOUHBlBCIUfWz7M9Lsrtm6X9cvCP+F5OwLfEZvLFkilw
# TQ6nqUYGc0HRHtrThlJ46lvLsCQJWPbpRtpp4TIz2yYq0mPHJZbf3AMyoknebLgV
# Du6Y2TCrCVXOWbJo2+QwETAb/pFRoQYOAnBEHbmGwsmN8n+A+IxTFy3Sa3fu5PdE
# ELg=
# SIG # End signature block
